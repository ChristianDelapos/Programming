

package finaldesign;


public class FinalDesign {

    String title,genre,lengthM;
     
    public FinalDesign  (String title, String genre, String lengthM){
    this.title = title;
    this.genre = genre;
    this.lengthM = lengthM;
    }
    
}
